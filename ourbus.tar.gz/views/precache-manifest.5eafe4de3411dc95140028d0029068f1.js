self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "7410a6621bd14bf8cc18501d1bc6bdc2",
    "url": "/index.html"
  },
  {
    "revision": "f074e6f8fcc289b53b50",
    "url": "/static/css/main.6285a5df.chunk.css"
  },
  {
    "revision": "910d24c504774a5d397d",
    "url": "/static/js/2.f80ce7e4.chunk.js"
  },
  {
    "revision": "f074e6f8fcc289b53b50",
    "url": "/static/js/main.9e86faa8.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "77a8fa24802cde81a38c38e74eada207",
    "url": "/static/media/baby_bg.77a8fa24.jpg"
  },
  {
    "revision": "3520ceeb01cdfdf480f57edca9538066",
    "url": "/static/media/facebook.3520ceeb.png"
  },
  {
    "revision": "ea1c270f65507c3f5330e9249fd02c5d",
    "url": "/static/media/google.ea1c270f.png"
  },
  {
    "revision": "a7fdb37a9a2c33c5e7392212dd473fec",
    "url": "/static/media/logo.a7fdb37a.png"
  },
  {
    "revision": "0378bf7faef433d43d2ad21cb8ab010d",
    "url": "/static/media/segoeui-bold.0378bf7f.svg"
  },
  {
    "revision": "1ede736b2621c208c3371d0d349b9a32",
    "url": "/static/media/segoeui-bold.1ede736b.ttf"
  },
  {
    "revision": "52382539737f4e9913e4bf6b9966bee3",
    "url": "/static/media/segoeui-bold.52382539.woff"
  },
  {
    "revision": "b0e110c8d14b54879143bcab670bc1bf",
    "url": "/static/media/segoeui-bold.b0e110c8.eot"
  },
  {
    "revision": "be5b36f32d15f49bb378a8ca844005bb",
    "url": "/static/media/segoeui-bold.be5b36f3.woff2"
  },
  {
    "revision": "3481b4b4ca5b630cc6e9d20f3ff9dcad",
    "url": "/static/media/segoeui.3481b4b4.ttf"
  },
  {
    "revision": "5cf4a84859936a137104645101359891",
    "url": "/static/media/segoeui.5cf4a848.svg"
  },
  {
    "revision": "6a3131987fa7862858443e52e92a4e12",
    "url": "/static/media/segoeui.6a313198.woff2"
  },
  {
    "revision": "9a2931180d6b1dc7b33052657eef554b",
    "url": "/static/media/segoeui.9a293118.woff"
  },
  {
    "revision": "c5ae2de147e52f50c82f8c38bb9e97ea",
    "url": "/static/media/segoeui.c5ae2de1.eot"
  }
]);